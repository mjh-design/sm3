
 extern void sm3_c(/* INPUT */int len, const /* INPUT */svOpenArrayHandle data, const /* OUTPUT */svOpenArrayHandle res);
